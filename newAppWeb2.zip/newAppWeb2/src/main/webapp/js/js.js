/**
 * JS especifico para la visibilidad de la pagina web de los menus.
 * Ojo aquí no hace faltya indicar las etiquetas <script>
 * 
 */

     /*   document.addEventListener("DOMContentLoaded", function () {
            // Función para mostrar la sección adecuada basada en el hash
            function mostrarSeccion() {
                // Obtener el hash actual de la URL o usar '#inicio' como valor predeterminado
                var hash = window.location.hash || '#inicio';
                
                // Ocultar todas las secciones
                document.querySelectorAll('section').forEach(function (section) {
                    section.style.display = 'none';
                });
        
                // Mostrar la sección que corresponde al hash actual
                var section = document.querySelector(hash);
                if (section) {
                    section.style.display = 'block';
                }
            }
        
            // Agregar listener para cambios en el hash
            window.addEventListener('hashchange', mostrarSeccion);
            mostrarSeccion();  // Ejecutar al cargar para establecer la sección inicial basada en el hash
        
            // Agregar listener para el botón que maneja la visibilidad del área personal
            document.getElementById('toggleAreaPersonal').addEventListener('click', function () {
                var areaPersonal = document.getElementById('formulario_area_personal');
                // Alternar la visibilidad de 'Mi área personal'
                if (areaPersonal.style.display === 'block') {
                    areaPersonal.style.display = 'none';
                } else {
                    // Asegurarse de que todas las otras secciones estén ocultas
                    document.querySelectorAll('section').forEach(function (section) {
                        section.style.display = 'none';
                    });
                    areaPersonal.style.display = 'block';
                }
            });
        });
        
    */