/**
 * 
 * JS para recibir los datos de contactanos
 * 
 */

 $("#btnEnviar").click (btnEnviar)
 	function btnEnviar (event){
					
	event.preventDefault();
		var nombre = $("#nombre").val()
		var apellidos = $("#apellidos").val()
		var email = $("#email").val()
		var telefono = $("#telefono").val()
		var mensaje = $("#mensaje").val()
		
		
		
	$.post("SV_FormContactanos",
	
	{
		nombre: nombre,
		apellidos: apellidos,
		email: email,
		telefono: telefono,
		mensaje: mensaje,
	},
	function(data){
	 alert (data)
	 console.log("Hola Hola")
		
	} )
	
	
	//Creo una variable para recinir todos los datos del servidor.
	/*alert(nombre)
	var datosFormulario = new FormData()
	datosFormulario.append ("nombre",nombre)
	datosFormulario.append ("apellidos",apellidos)
	var datos = {
		nombre: nombre,
		apellidos: apellidos,
		email: email,
		telefono: telefono,
		mensaje: mensaje,
	}
	fetch("SV_FormContactanos", 
	
	{
		method:'POST',
		//headers: {'Content-Type':'application/json'},
		body: datosFormulario		
		
		
	})
	.then(r => r.text())
	.then(texto => alert(texto))*/
	
	
 }
	 