/**
 * 
 * Script para controlar la visibilidad del formulario de inscripcion.
 * 
 */

                    document.addEventListener('DOMContentLoaded', function () {
                        const centroSelect = document.getElementById('centro'); //--Utilizo las id centrobrains para hacer una logica de seleccion.//
                        const deporteSelect = document.getElementById('deporte'); //--Utilizo las id deporte para hacer una logica de seleccion.//

                        const deportesPorCentro = {
                            "Orgaz": ["Baloncesto"],
                            "ArturoSoria": ["Baloncesto"],
                            "Moraleja": ["Baloncesto", "Fútbol", "Natación", "Waterpolo", "Sincronizada", "Nado Libre"]
                        };

                        centroSelect.addEventListener('change', function () {
                            const centro = this.value;
                            const deportes = deportesPorCentro[centro] || [];

                            // Limpiar el desplegable de deportes
                            deporteSelect.innerHTML = '';

                            // Siempre añade una opción deshabilitada como primera opción
                            const opcionPorDefecto = new Option("-- Por favor, elige un Deporte --", "");
                            opcionPorDefecto.disabled = true;
                            opcionPorDefecto.selected = true;
                            deporteSelect.add(opcionPorDefecto);

                            // Añadir nuevas opciones basadas en el centro elegido con la estructutra for
                            deportes.forEach(function (deporte) {
                                deporteSelect.add(new Option(deporte, deporte));
                            });
                        });
                        
                        document.getElementById("enviarInscripcion").addEventListener("click",(event)=>{
							
							
							var password = document.getElementById("password").value
							
							console.log(password)
							
							var repitePassword = document.getElementById("repitePassword").value
							
							console.log(repitePassword)
							
							if(password != repitePassword){
								event.preventDefault()
								alert ("Has puesto dos contraseñas diferentes")
								document.getElementById("password").focus()
								
							}
						})
                    });
                