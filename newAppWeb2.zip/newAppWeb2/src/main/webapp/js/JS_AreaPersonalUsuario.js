/**
 * 
 */

 $(document).ready(function() {
    cargarUsuarios();

    function cargarUsuarios() {
        $.get("SV_ListarUsuario", function(data) {
            let usuarios = JSON.parse(data);
            let tabla = $("#usuariosTable tbody");
            tabla.empty();

            usuarios.forEach(function(usuario) {
                let fila = `<tr>
                    <td>${usuario.id}</td>
                    <td>${usuario.nombre}</td>
                    <td>${usuario.apellidos}</td>
                    <td>${usuario.email}</td>
                    <td>${usuario.telefono}</td>
                    <td>
                        <button onclick="editarUsuario(${usuario.id})">Editar</button>
                        <button onclick="eliminarUsuario(${usuario.id})">Eliminar</button>
                    </td>
                </tr>`;
                tabla.append(fila);
            });
        });
    }

    window.editarUsuario = function(id) {
        // Aquí puedes implementar la lógica para editar un usuario
        alert("Editar usuario con ID: " + id);
    };

    window.eliminarUsuario = function(id) {
        if (confirm("¿Estás seguro de que deseas eliminar este usuario?")) {
            $.ajax({
                url: "SV_EliminarUsuario", // Asegúrate de tener un servlet para eliminar usuarios
                method: "POST",
                data: { id: id },
                success: function() {
                    cargarUsuarios();
                }
            });
        }
    };
});